%% Elemento Barra-Viga 3D (RM 2021)

clear
close all



Nodes =[0 0 0; 0 1 0; 0 2 0; 0 3 0; 0 4 0; 3/4 4 0; 3/2 4 0; 9/4 4 0;...
    3 4 0; 0 4 -3/4; 0 4 -3/2; 0 4 -9/4; 0 4 -3];

lnodal={[1 2],[2 3],[3 4],[4 5],[5 6],[6 7],[7 8],[8 9],...
    [5 10],[10 11],[11 12],[12 13]};


[nnode,~]=size(Nodes);
[~,nelem]=size(lnodal);
ndof=nnode*6; % cada n� tem 6 graus de liberdade : 3 transla��es (Tx,ty e Tz) + 3 rota��es (Rx, Ry, rz)

%% parametros de geometria e material

A  =  2e-2;           % �rea da sec��o da viga
E  =  70e9;           % M�dulo de Young do material da viga
G  =  27e9;           % M�dulo de corte do material da viga [ G=E/2(1+v) onde v � coeficiente de Poisson ]
Iz = 20e-5;           % Momento de In�rcia da sec��o da viga em z
Iy = 10e-5;           % Momento de In�rcia da sec��o da viga segundo y
J  =  5e-5;           % Momento Polar de In�rcia da secc�o da viga

%% condi��es de fronteira 
fixed_nodes=[1 9 13];
free_dofs=(1:ndof);
for inode=1:length(fixed_nodes)
    fixnode=fixed_nodes(inode);
    fixed_dofs= ((fixnode-1)*6+1:fixnode*6);
    free_dofs=setxor(free_dofs, fixed_dofs);
end
 % e carregamentos
F=zeros(ndof,1);                       % inicializa��o do vetor de carregamento
force_dofs=[(6*4)+1,(6*4)+3];          % Aplica��o dos carregamentos
force_val=[-10e3 20e3];                % Valor dos carregamentos
F(force_dofs)=force_val;  


%% gera��o da matriz de rigidez (montagem da matriz)
K=zeros(ndof,ndof); %inicializa��o da matriz de rigidez

for ielem=1:nelem
    
    % coordenas do nodo 1
    x1 = Nodes(lnodal{ielem}(1),1);
    y1 = Nodes(lnodal{ielem}(1),2);
    z1 = Nodes(lnodal{ielem}(1),3);
    
    % coordenadas do nodo 2
    x2 = Nodes(lnodal{ielem}(2),1);
    y2 = Nodes(lnodal{ielem}(2),2);
    z2 = Nodes(lnodal{ielem}(2),3);

    
    % Ponto 3, para definir a dire��o da sec��o da viga
    x3 = (x2-x1)/2 + x1 + 1;
    y3 = (y2-y1)/2 + y1 + 1;    
    z3 = (z2-z1)/2 + z1;
    
    V1 = [x1 y1 z1];
    V2 = [x2 y2 z2];
    V3 = [x3 y3 z3];
    
    % comprimento da barra
    L = sqrt((x2-x1)^2+(y2-y1)^2+(z2-z1)^2);
    
    % cossenos diretores
    lx = (x2-x1)/L;
    mx = (y2-y1)/L;
    nx = (z2-z1)/L;
      
    aux = cross((V2-V1),(V3-V1))/norm(cross((V2-V1),(V3-V1)));
    lz = aux(1);
    mz = aux(2);
    nz = aux(3);
    
    aux = cross(aux,[lx,mx,nx]);
    ly = aux(1);
    my = aux(2);
    ny = aux(3);
    
    % matriz de transforma��o
    T_aux = [lx mx nx
             ly my ny
             lz mz nz];
    
    T = [ T_aux   zeros(3) zeros(3) zeros(3)
         zeros(3)  T_aux   zeros(3) zeros(3)
         zeros(3) zeros(3)  T_aux   zeros(3)
         zeros(3) zeros(3) zeros(3)  T_aux];

    % Matriz de Rigidez ( sem transforma��o de vari�veis )
    S1 = [E*A/L 0           0 0 0 0
          0     12*E*Iz/L^3   0   0    0     6*E*Iz/L^2
          0     0      12*E*Iy/L^3 0   -6*E*Iy/L^2  0
          0 0 0 G*J/L 0 0
          0 0 -6*E*Iy/L^2 0 4*E*Iy/L 0
          0 6*E*Iz/L^2 0 0 0 4*E*Iz/L];
    
    S2 = [-E*A/L 0 0 0 0 0
        0 -12*E*Iz/L^3 0 0 0 6*E*Iz/L^2
        0 0 -12*E*Iy/L^3 0 -6*E*Iy/L^2 0
        0 0 0 -G*J/L 0 0
        0 0 6*E*Iy/L^2 0 2*E*Iy/L 0
        0 -6*E*Iz/L^2 0 0 0 2*E*Iz/L];
    
    S3 = [-E*A/L 0 0 0 0 0
        0 -12*E*Iz/L^3 0 0 0 -6*E*Iz/L^2
        0 0 -12*E*Iy/L^3 0 6*E*Iy/L^2 0
        0 0 0 -G*J/L 0 0
        0 0 -6*E*Iy/L^2 0 2*E*Iy/L 0
        0 6*E*Iz/L^2 0 0 0 2*E*Iz/L];
    
    S4 = [E*A/L 0 0 0 0 0
        0 12*E*Iz/L^3 0 0 0 -6*E*Iz/L^2
        0 0 12*E*Iy/L^3 0 6*E*Iy/L^2 0
        0 0 0 G*J/L 0 0
        0 0 6*E*Iy/L^2 0 4*E*Iy/L 0
        0 -6*E*Iz/L^2 0 0 0 4*E*Iz/L];
    
    Kelem = [S1 S2 ; S3 S4];    % Antes da transforma��o de vari�veis
    Kelem = T'*Kelem*T;         % Ap�s a transforma��o de vari�veis
    
    % Montagem da matriz de rigidez do elemento na matriz de rigidez global
    no1=6*lnodal{ielem}(1)-5; %1� dof do 1� n� do elemento ielem
    no2=6*lnodal{ielem}(2)-5; %1� dof do 2� n� do elemento ielem
    
    indexB = [no1:no1+5,no2:no2+5];
    
    K(indexB,indexB) = K(indexB,indexB)+Kelem;
    
end

%% aplica��o das condi��es de fronteira
Kp=K(free_dofs, free_dofs);
Fp=F(free_dofs,1);

%% Resolu��o do sistema de equa��es
Up=Kp\Fp;
U=zeros(ndof,1);
U(free_dofs)=Up;



%% output de resultados

% listagem de deslocamentos
for inode=1:nnode
    dx(inode)=U(inode*6-5);
    dy(inode)=U(inode*6-4);
    dz(inode)=U(inode*6-3);
    Rx(inode)=U(inode*6-2);
    Ry(inode)=U(inode*6-1);
    Rz(inode)=U(inode*6);
    nodes(inode)=inode; 
end
    VarNames = {'Node', 'Tx', 'Ty', 'Tz', 'Rx', 'Ry', 'Rz'};
    T = table(nodes',dx',dy',dz',Rx',Ry',Rz','VariableNames',VarNames)
    


%representa��o da deformada


aF=3e-5;%factor de amplifica��o da deformada


for ielem=1:nelem
    
   no1=lnodal{ielem}(1); % 1� n� do elemento ielem
   no2=lnodal{ielem}(2); % 2� n� do elemento ielem
   dof1=no1*6-5; %1� dof do n� 1 do elemento ielem
   dof2=no2*6-5; %1� dof do n� 2 do elemento ielem 
   
   x1=Nodes(no1,1); y1=Nodes(no1,2); z1=Nodes(no1,3);
   x2=Nodes(no2,1); y2=Nodes(no2,2); z2=Nodes(no2,3);
 
   LinesU(ielem,1:6)=[x1 x2 y1 y2 z1 z2];
      
   LinesUD(ielem,1:6)=LinesU(ielem,1:6)+1/aF*[U(dof1) U(dof2) U(dof1+1) U(dof2+1) U(dof1+2) U(dof2+2)];
      
end

figure(1); clf; hold on; axis equal

xlabel('X');ylabel('Y');zlabel('Z');

for i=1:size(LinesU,1);
    undef=line(LinesU(i,1:2),LinesU(i,3:4),LinesU(i,5:6)); set(undef,'LineStyle',':','color','b','Linewidth',.5);
    def(i)=line(LinesU(i,1:2),LinesU(i,3:4),LinesU(i,5:6)); set(def(i),'LineStyle','-','color','b','Linewidth',2);
end%

hold off

view(3); grid on
view(135,30);camup([0 1 0])

% anima��o

%animdef=[NaN,NaN];
max_anim_steps=100;time_step=0.01;
for anim_step=1:max_anim_steps
    pause(time_step);
    for ielem=1:nelem
        no1=lnodal{ielem}(1);%1� n� do elemento ielem
        no2=lnodal{ielem}(2); %2� n� do elemento ielem
        dof1=no1*6-5; %1� dof do n� 1 do elemento ielem
        dof2=no2*6-5; %1� dof do n� 2 do elemento ielem 
      
        LinesUD(ielem,1:6)=LinesU(ielem,1:6)+anim_step/max_anim_steps*...
            1/aF*[U(dof1) U(dof2) U(dof1+1) U(dof2+1) U(dof1+2) U(dof2+2)];
       
        set(def(ielem),'XData',LinesUD(ielem,1:2),'YData',LinesUD(ielem,3:4),...
            'ZData',LinesUD(ielem,5:6));
    end

    
end
